import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.analysis.*; 
import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class yoanna_frog extends PApplet {




Minim minim;
AudioInput in;
FFT fft;
// \u9752\u86d9
Mover frog;
// \u4e24\u53ea\u866b\u5b50
RandomMover bug1;
RandomMover bug2;

// 0 \u8868\u793a\u6b22\u8fce
// 1 \u8868\u793a\u6e38\u620f\u4e2d
// 2 \u901a\u5173\u754c\u9762
int status=0;
// 1,2,3,4 \u8868\u793a\u56db\u4e2a\u5173\u5361
int stage=1;

int beginFrame=0;

public void setup() {
  size(600, 600);
  imageMode(CENTER);

  // \u521b\u5efa\u97f3\u9891\u76f8\u5173\u5bf9\u8c61
  minim=new Minim(this);
  in=minim.getLineIn();
  fft=new FFT(in.bufferSize(), in.sampleRate());
  // \u521d\u59cb\u5316\u9752\u86d9\u548c\u866b\u5b50
  frog=new Mover("frog.png");
  frog.setPos(0, height);
  bug1=new RandomMover("bug1.png");
  bug2=new RandomMover("bug2.png");
}
public void draw() {
  // \u6839\u636e\u4e0d\u540c\u7684\u72b6\u6001\u753b\u56fe
  clear();
  if (status==0) {
    draw0();
  } else if (status==1) {
    draw1();
  } else if (status==2) {
    draw2();
  }
}

public void keyReleased() {
  // \u6309\u4efb\u610f\u952e\u76d8\u5f00\u59cb\u6e38\u620f
  if (status==0||status==2) {
    status=1;
    stage=1;
    bug1.reset();
    bug1.die();
    bug2.reset();
    bug2.speedRate=0.5f;
    beginFrame=frameCount;
  }
//  if (key=='s') {
//   all bugs die
//  }
}

public void draw0() {
  // \u663e\u793a\u6b22\u8fce\u5c4f\u5e55
  textSize(100 );
  text("Walcome!", 70, 250);
  textSize(40);
  text("press any key to play", 150, 400);
}

public void draw1() {
  // \u5206\u6790\u97f3\u9891\u7a0b\u5e8f\uff0c\u83b7\u53d6\u632f\u5e45\u548c\u9891\u7387
  fft.forward(in.mix);
  long bandSum=0;
  long freqSum=0;
  for (int i = 0; i < fft.specSize (); i++) {
    bandSum+=fft.getBand(i)*8;
    freqSum+=fft.getFreq(i)*8;
    // draw the line for frequency band i, scaling it up a bit so we can see it
    // line( i, height, i, height - fft.getBand(i)*8 );
  }
  float freq=map(freqSum/fft.specSize(), 100, 1000, 0, width);
  float band=height-map(bandSum/fft.specSize(), 0, 200, 0, height);

  frog.setPos(freq, band);

  // \u753b\u51fa\u9752\u86d9\u548c\u866b\u5b50\u4f4d\u7f6e
  frog.draw();
  bug1.draw();
  bug2.draw();

  //rect(0, 0, band, 10);
  //rect(0, 0, 10, freq);
  //println(freqSum/fft.specSize());
  //ellipse(band, freq, 100, 100);

  // \u68c0\u67e5\u6709\u6ca1\u6709\u88ab\u5403\u6389
  checkEat();
}

public void draw2() {
  // \u606d\u559c\u901a\u5173
  textSize(60);
  text("Congratulations!", 70, 250);
  textSize(30);
  text("press any key to play again", 150, 400);
}

public void checkEat() {
  // \u68c0\u67e5\u866b\u5b50\u662f\u5426\u88ab\u9752\u86d9\u5403\u6389
  if (frog.loc.dist(bug1.loc)<60) {
    bug1.die();
  }
  if (frog.loc.dist(bug2.loc)<60) {
    bug2.die();
  }
  // \u5982\u679c\u866b\u5b50\u5168\u90e8\u88ab\u5403\u6389\uff0c\u90a3\u4e48\u81ea\u52a8\u8fdb\u884c\u4e0b\u4e00\u4e2a\u5173\u5361
  if (!bug1.alive&&!bug2.alive) {
    if (stage==1) {
      bug1.reset();
      bug1.die();
      bug2.reset();
      bug2.speedRate=1.5f;
      stage++;
    } else if (stage==2) {
      bug1.reset();
      bug1.speedRate=0.5f;
      bug2.reset();
      bug2.speedRate=0.5f;
      stage++;
    } else if (stage==3) {
      bug1.reset();
      bug1.speedRate=1.5f;
      bug2.reset();
      bug2.speedRate=1.5f;
      stage++;
    } else if (stage==4) {
      stage=1;
      status=2;
    }
  }
}
// \u9752\u86d9\u7c7b
class Mover {
  PImage img;
  PVector loc;
  PVector lastLoc;
  PVector velocity;
  PVector acceleration;
  Mover(String img) {
    this.img=loadImage(img);
    loc = new PVector(0, height);
    lastLoc=new PVector(0, height);
    velocity=new PVector(0, 0);
    acceleration=new PVector(0, 0);
  }
  public void setPos(float x, float y) {
    PVector target=new PVector(x, y);
    loc=PVector.add(lastLoc, PVector.div(PVector.sub(target, lastLoc), 10));
    lastLoc.x=loc.x;
    lastLoc.y=loc.y;
  }
  public void update() {
    velocity.add(acceleration);
    loc.add(velocity);
  }
  public void checkEdge() {
    loc.x=constrain(loc.x, 0, width);
    loc.y=constrain(loc.y, 0, height);
  }
  public void display() {
    image(img, loc.x, loc.y, 100, 100);
  }
  public void draw() {
    update();
    checkEdge();
    display();
  }
}
// \u866b\u5b50\u7c7b
class RandomMover extends Mover {
  boolean alive=true;
  float speedRate=1;

  RandomMover(String img) {
    super(img);
    loc.x=random(width);
    loc.y=random(height/3);
  }

  public void update() {
    acceleration.x=random(-1, 1)*speedRate;
    acceleration.y=random(-1, 1)*speedRate;
    velocity.add(acceleration);
    velocity.limit(5*speedRate);
    loc.add(velocity);
  }

  public void checkEdge() {

    if (loc.x<=30||loc.x>=width-30) {

      velocity.x*=-1;
    }
    if (loc.y<=30||loc.y>=height/3-30) {
      velocity.y*=-1;
    }

    loc.x=constrain(loc.x, 30, width-30);
    loc.y=constrain(loc.y, 30, height/3-30);
  }

  public void display() {
    image(img, loc.x, loc.y, 30, 30);
  }

  public void draw() {
    if (alive) {
      update();
      checkEdge();
      display();
    }
  }

  public void die() {
    alive=false;
  }
  public void reset() {
    speedRate=1;
    alive=true;
    loc.x=random(width);
    loc.y=random(height/3);
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "yoanna_frog" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
