import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.pdf.*; 
import java.util.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class yoanna_kaleidoscope extends PApplet {




int WIDTH=800, HEIGHT=800;
final int r=50;
// \u5f53\u524d\u5708\u6570
int level=0;
// \u76f8\u90bb\u56fe\u50cf\u7f29\u653e\u6bd4\u4f8b
final float scala=0.8f;
boolean savePDF = false;
ArrayList<Character> types;
ArrayList<Character> nums;
HashMap<Character, PImage> keyPngs;

// \u5f53\u524d\u6309\u952e
char typeKey='a';
// \u5927\u5c0f\u53d8\u6362\u56fe\u50cf\u7684\u4e2a\u6570
char numberKey='1';
int typeIndex=0;
int numberIndex=0;
int stepIndex=0;

public void setup() {
  size(WIDTH, HEIGHT);
  background(255);
  ellipseMode(CENTER);
  smooth();

  imageMode(CENTER);

  types=new ArrayList<Character>();
  nums=new ArrayList<Character>();
  // \u6309\u952e\u5bf9\u5e94\u7684\u56fe\u50cf\u653e\u5230 map \u4e2d
  keyPngs=new HashMap();
  keyPngs.put('a', loadImage("1.png"));
  keyPngs.put('b', loadImage("2.png"));
  keyPngs.put('c', loadImage("3.png"));
  keyPngs.put('d', loadImage("4.png"));
  keyPngs.put('e', loadImage("5.png"));
  keyPngs.put('f', loadImage("6.png"));
  keyPngs.put('g', loadImage("7.png"));
  keyPngs.put('h', loadImage("8.png"));
  keyPngs.put('i', loadImage("9.png"));
}

public void draw() {
  // \u662f\u5426\u4fdd\u5b58pdf
  if (savePDF) beginRecord(PDF, "pdf/####.pdf"); 
  background(255);
  // \u753b\u51fa\u56fe\u5f62
  for (int i=0; i<types.size (); i++) {
    drawCircle(i, types.get(i), PApplet.parseInt(String.valueOf(nums.get(i))), 0);
  }
  // \u4fdd\u5b58pdf
  if (savePDF) {
    endRecord();
    savePDF=false;
  }
}

public void keyReleased() {
  // \u5982\u679c\u662f a-i \u90a3\u4e48\u66f4\u6362\u56fe\u5f62\u6837\u5f0f
  if (keyPngs.keySet().contains(key)) {
    if (level==0) {
      types.add(key);
      nums.add('0');
      level++;
    }
    typeKey=key;
  } else if (key=='1'||key=='2'||key=='3'||key=='4'||key=='5'
    ||key=='6'||key=='7'||key=='8'||key=='9'||key=='0') {
    // 1-0 \u4fee\u6539\u56fe\u5f62\u5927\u5c0f\u5207\u6362\u7684\u4e2a\u6570
    types.add(typeKey);
    nums.add(key);
  } else if (key=='p') { // p \u952e\u4fdd\u5b58
    savePDF=true;
  }
}

// 
public void drawCircle(int theLevel, char type, int n, int noDraw) {
  int R=theLevel*r;
  noStroke();
  fill(random(255), random(255), random(255));
  pushMatrix();
  translate(width/2, height/2);

  if (theLevel==0) {
    // \u4e2d\u5fc3\u7684\u5706
    int rr=r;
    image(keyPngs.get(type), R, 0, rr, rr);
  } else {
    // \u4e2d\u5fc3\u4e4b\u5916\u7684\u56fe\u7247
    int rr=r;
    for (int i=0; i<6*theLevel; i++) {
      if (n>0) { // \u7f29\u653e\u56fe\u7247
        rr=PApplet.parseInt(r*pow(scala, n-abs(i%(2*n)-n)));
      }
      // \u65cb\u8f6c\u5e76\u753b\u4e00\u4e2a\u56fe\u7247
      rotate(TWO_PI/6/theLevel);
      image(keyPngs.get(type), R, 0, rr, rr);
    }
  }
  popMatrix();
}
public void drawShape(int num, int centerX, int centerY, float innerR, float outerR) {
  PVector[] points = new PVector[ num * 2 ];
  float angle = TWO_PI / points.length;

  for ( int i = 0; i < points.length; i++ ) {
    float x, y;
    if ( i % 2 == 0 ) {
      x = cos( angle * i ) * outerR;
      y = sin( angle * i ) * outerR;
    } else {
      x = cos( angle * i ) * innerR;
      y = sin( angle * i ) * innerR;
    }
    points[i] = new PVector( x, y );
  }

  beginShape();
  for (int i = 0; i < points.length; i++) {
    vertex( points[i].x+centerX, points[i].y+centerY );
  }
  endShape(CLOSE);
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "yoanna_kaleidoscope" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
