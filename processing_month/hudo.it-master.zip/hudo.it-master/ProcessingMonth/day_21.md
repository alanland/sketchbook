Processing Month
=====
第二十一天 **适合的方块**
----

今天我们来写一个新的算法，这是一副[我的速写本](http://www.flickr.com/photos/vormplus/sets/72157622480411441/)上的绘画。我不想过多的阐述这个算法，我希望您能自己从代码中领会，这个代码也许会对建筑、城市规划或图形设计师在构造网格时有用，以下是原始图像和算法输出的图像。

![](http://img.vormplus.be/blog/moleskine-sketchbook-grid.jpg)

![](http://img.vormplus.be/blog/rectangle-fitting-algorithm.png)

##下载
[Processing Month第二十一天的文件](http://img.vormplus.be/downloads/processing_month_day_021.zip)