Processing Month
=====
概述
----

Processing Month已经全部完成了，这真的是一部很棒的教程。在推特、电子邮箱和博客上我收到了许许多多的响应。我想要感谢Marius Wats和Casey Reas在推特上提到Processing Month这篇教程。我也很想感谢Liz Taylor、Pete Prodoehl以及Ian Bowman,他们也尝试制作了他们的Processing Month。

                                  Jan Vantomme